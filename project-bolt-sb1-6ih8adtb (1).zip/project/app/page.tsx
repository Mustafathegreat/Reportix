'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  Workflow, 
  BrainCircuit, 
  TerminalSquare, 
  FileText, 
  Menu, 
  X, 
  ChevronRight,
  Microscope,
  Bot,
  CodeSquare,
  Zap,
  Users,
  TrendingUp,
  Database,
  Cpu,
  Globe
} from 'lucide-react';

export default function ReportixHomePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    services: [],
    description: '',
    timeline: '',
    budget: ''
  });

  const services = [
    {
      icon: BarChart3,
      title: 'Dashboarding & BI',
      description: 'Custom dashboards using Power BI, Tableau, Looker Studio & Excel'
    },
    {
      icon: Workflow,
      title: 'Report Automation',
      description: 'Use of Power Automate, Python, and VBA macros to reduce manual work'
    },
    {
      icon: Database,
      title: 'Data Structuring',
      description: 'Clean, transform, and model datasets using SQL and Python'
    },
    {
      icon: BrainCircuit,
      title: 'AI-Powered Analysis',
      description: 'Using ChatGPT and GitHub Copilot to enhance reports with smart summaries'
    },
    {
      icon: TerminalSquare,
      title: 'End-to-End Workflows',
      description: 'Seamless integration of tools like Excel, SQL, and APIs into automated flows'
    }
  ];

  const portfolioItems = [
    {
      title: 'Power BI - Sales Overview',
      description: 'Interactive sales dashboard with real-time KPIs',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop',
      color: 'bg-blue-500'
    },
    {
      title: 'Excel - Automated KPI Tracker',
      description: 'Self-updating Excel dashboard with VBA automation',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop',
      color: 'bg-green-500'
    },
    {
      title: 'Tableau - Customer Sentiment Visual',
      description: 'Advanced analytics dashboard for customer insights',
      image: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=600&h=400&fit=crop',
      color: 'bg-purple-500'
    },
    {
      title: 'Looker Studio - Digital Marketing Report',
      description: 'Comprehensive marketing performance analytics',
      image: 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=600&h=400&fit=crop',
      color: 'bg-orange-500'
    }
  ];

  const tools = [
    { name: 'Power BI', description: 'Visual dashboards at scale' },
    { name: 'Tableau', description: 'Advanced data visualization' },
    { name: 'Excel', description: 'Automated reporting & analysis' },
    { name: 'Python', description: 'Clean, automate, and extract insights' },
    { name: 'SQL', description: 'Database querying & management' },
    { name: 'VBA', description: 'Excel automation & macros' },
    { name: 'Power Automate', description: 'Workflow automation' },
    { name: 'Looker Studio', description: 'Google-based dashboards' },
    { name: 'ChatGPT', description: 'AI-powered insights' },
    { name: 'Copilot', description: 'Code assistance & automation' }
  ];

  const handleServiceToggle = (service) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Handle form submission
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-gray-900">Reportix</h1>
              </div>
            </div>
            
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <a href="#services" className="text-gray-600 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Services</a>
                <a href="#portfolio" className="text-gray-600 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Portfolio</a>
                <a href="#ai-lab" className="text-gray-600 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">AI Lab</a>
                <a href="#contact" className="text-gray-600 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Contact</a>
              </div>
            </div>
            
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-600 hover:text-gray-900 focus:outline-none focus:text-gray-900"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-b border-gray-200">
              <a href="#services" className="text-gray-600 hover:text-blue-600 block px-3 py-2 rounded-md text-base font-medium">Services</a>
              <a href="#portfolio" className="text-gray-600 hover:text-blue-600 block px-3 py-2 rounded-md text-base font-medium">Portfolio</a>
              <a href="#ai-lab" className="text-gray-600 hover:text-blue-600 block px-3 py-2 rounded-md text-base font-medium">AI Lab</a>
              <a href="#contact" className="text-gray-600 hover:text-blue-600 block px-3 py-2 rounded-md text-base font-medium">Contact</a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Automate. Analyze. Act.
              <span className="block text-blue-600">— With Reportix.</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              From Excel macros to AI-powered dashboards, we turn messy data into sharp, automated insights using Power BI, Python, SQL, Tableau, and modern AI copilots.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                <Zap className="mr-2 h-5 w-5" />
                Explore Our Services
              </Button>
              <Button size="lg" variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                Request a Free Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What We Deliver</h2>
            <p className="text-xl text-gray-600">Comprehensive data solutions tailored to your business needs</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300 border-0 shadow-md">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <service.icon className="h-6 w-6 text-blue-600" />
                    </div>
                    <CardTitle className="text-lg">{service.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">{service.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Dashboard Samples</h2>
            <p className="text-xl text-gray-600">See what we can build for your business</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {portfolioItems.map((item, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="relative h-48 bg-gradient-to-br from-gray-100 to-gray-200">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/20"></div>
                </div>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {item.title}
                    <Badge variant="outline" className="ml-2">Sample</Badge>
                  </CardTitle>
                  <CardDescription>{item.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full">
                    View Sample
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* AI Lab Section */}
      <section id="ai-lab" className="py-16 bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Reportix AI Lab</h2>
              <Bot className="h-8 w-8 text-purple-600" />
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A sandbox where we test and deploy experimental automations using ChatGPT, Python agents, and Excel Copilot. We turn experimental ideas into client-ready workflows.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="text-center">
              <div className="p-4 bg-white rounded-full w-16 h-16 mx-auto mb-4 shadow-lg">
                <Microscope className="h-8 w-8 text-purple-600 mx-auto" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Research & Development</h3>
              <p className="text-gray-600">Testing cutting-edge automation techniques</p>
            </div>
            <div className="text-center">
              <div className="p-4 bg-white rounded-full w-16 h-16 mx-auto mb-4 shadow-lg">
                <Bot className="h-8 w-8 text-blue-600 mx-auto" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">AI Integration</h3>
              <p className="text-gray-600">Leveraging ChatGPT and AI copilots</p>
            </div>
            <div className="text-center">
              <div className="p-4 bg-white rounded-full w-16 h-16 mx-auto mb-4 shadow-lg">
                <CodeSquare className="h-8 w-8 text-green-600 mx-auto" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Custom Solutions</h3>
              <p className="text-gray-600">Tailored workflows for unique challenges</p>
            </div>
          </div>
          
          <div className="text-center">
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-white">
              Talk to the Lab
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Tools We Use</h2>
            <p className="text-xl text-gray-600">Industry-leading technologies for maximum impact</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {tools.map((tool, index) => (
              <div key={index} className="group text-center p-4 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                <div className="p-3 bg-blue-100 rounded-lg w-16 h-16 mx-auto mb-3 group-hover:bg-blue-200 transition-colors">
                  <div className="w-full h-full bg-blue-600 rounded opacity-80 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">{tool.name}</h3>
                <p className="text-sm text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  {tool.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Let's Build Together</h2>
            <p className="text-xl text-gray-600">Ready to transform your data? Let's discuss your project.</p>
          </div>
          
          <Card className="shadow-xl">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">What You Need (select all that apply)</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {['Dashboard', 'Report Automation', 'Data Cleaning', 'AI Workflow', 'BI Consulting', 'Other'].map((service) => (
                      <label key={service} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.services.includes(service)}
                          onChange={() => handleServiceToggle(service)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-gray-700">{service}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">Project Description</label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Tell us about your project, current challenges, and what you'd like to achieve..."
                    rows={4}
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="timeline" className="block text-sm font-medium text-gray-700 mb-2">Preferred Timeline</label>
                    <Input
                      id="timeline"
                      value={formData.timeline}
                      onChange={(e) => setFormData(prev => ({ ...prev, timeline: e.target.value }))}
                      placeholder="e.g., 2-4 weeks"
                    />
                  </div>
                  <div>
                    <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-2">Budget (Optional)</label>
                    <Input
                      id="budget"
                      value={formData.budget}
                      onChange={(e) => setFormData(prev => ({ ...prev, budget: e.target.value }))}
                      placeholder="e.g., $5,000 - $10,000"
                    />
                  </div>
                </div>
                
                <Button type="submit" size="lg" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  Send Inquiry
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Login Section */}
      <section className="py-16 bg-white border-t border-gray-200">
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Client Access Login</CardTitle>
              <CardDescription>Access your personalized dashboards and reports</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label htmlFor="login-email" className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <Input id="login-email" type="email" placeholder="your@email.com" />
              </div>
              <div>
                <label htmlFor="login-password" className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                <Input id="login-password" type="password" placeholder="••••••••" />
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Login</Button>
              <div className="text-center space-y-2">
                <a href="#" className="text-sm text-blue-600 hover:text-blue-800">Forgot Password?</a>
                <p className="text-sm text-gray-600">
                  Not a client yet? <a href="#contact" className="text-blue-600 hover:text-blue-800">Request access</a>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">Reportix</h3>
              <p className="text-gray-300 mb-4">
                We Make Your Life Easier With Data and Insights
              </p>
              <p className="text-gray-400 text-sm">
                © 2025 Reportix. Built with 💻 by data lovers.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">Services</a></li>
                <li><a href="#portfolio" className="text-gray-300 hover:text-white transition-colors">Portfolio</a></li>
                <li><a href="#ai-lab" className="text-gray-300 hover:text-white transition-colors">AI Lab</a></li>
                <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Connect</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">LinkedIn</a></li>
                <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">Get Free Demo</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>

      {/* Sticky CTA for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200 md:hidden z-40">
        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
          Get Free Demo
        </Button>
      </div>
    </div>
  );
}
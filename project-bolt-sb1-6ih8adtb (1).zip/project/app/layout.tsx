import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Reportix - Automate. Analyze. Act.',
  description: 'From Excel macros to AI-powered dashboards, we turn messy data into sharp, automated insights using Power BI, Python, SQL, Tableau, and modern AI copilots.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}